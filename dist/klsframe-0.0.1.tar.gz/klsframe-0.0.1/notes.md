Install package manager

````shell
python -m pip install --user pipx
````

Install packager

````shell
pipx install hatch
(windows) python "c:\users\me\appdata\roaming\python\python311\scripts\pipx.exe" install hatch
````
