# TODO: module for creating simple GUI components and applications
