import klsframe.klsframe.guiLayout as guiLayout
if __name__ == '__main__':
    table = guiLayout.GUITable()
    table.table_size = 11
    table.row_height = 28
    table.first_row_Y = 235

    tablecolumn = guiLayout.GUITableColumn()


